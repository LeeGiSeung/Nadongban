let date = new Date();

function startApp() {
  fetch('/process_voice_data', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json'
      },
      body: JSON.stringify({ text: '음성 입력 시작' })
  })
  .then(response => response.json())
  .then(data => {
      console.log('Server response:', data);
      showTable(data);
  })
  .catch(error => console.error('Error:', error));
}

// 결과를 표 형태로 화면에 표시하는 함수
function showTable(data) {
  var table = "<table border='1'><tr><th>date</th><th><img src='static/alcohol.png'></th><th><img src='static/outside.png'></th><th><img src='static/exercise.png'></th></tr>";
  data.forEach(row => {
      table += "<tr>";
      table += "<td>" + row[3] + "</td>";
      table += "<td>" + (row[2] === 1 ? '<img src="static/o.png">' : '<img src="static/x.png">') + "</td>";
      table += "<td>" + (row[1] === 1 ? '<img src="static/o.png">' : '<img src="static/x.png">') + "</td>";
      table += "<td>" + (row[0] === 1 ? '<img src="static/o.png">' : '<img src="static/x.png">') + "</td>";
      table += "</tr>";
  });
  table += "</table>";
  document.getElementById('result').innerHTML = table;
}

function showTable(data) {
  var table = "<table border='1'><tr><th>date</th><th>Alcohol</th><th>Outside</th><th>Exercise</th></tr>";
  data.forEach(row => {
      table += "<tr>";
      table += "<td>" + row[3] + "</td>";
      table += "<td>" + (row[2] === 1 ? '정상' : '비정상') + "</td>";
      table += "<td>" + (row[1] === 1 ? '정상' : '비정상') + "</td>";
      table += "<td>" + (row[0] === 1 ? '정상' : '비정상') + "</td>";
      table += "</tr>";
  });
  table += "</table>";
  document.getElementById('result').innerHTML = table;

  // 결과에 따라 helloText에 적절한 내용과 스타일 설정
  var helloText = document.getElementById('helloText');
  var result = data[0][0]; // 예시로 첫 번째 결과를 사용
  helloText.textContent = result === 1 ? "정상" : "비정상";
  helloText.style.color = result === 1 ? "green" : "red";
}

const renderCalendar = () => {
  const viewYear = date.getFullYear();
  const viewMonth = date.getMonth();

  document.querySelector('.year-month').textContent = `${viewYear}년 ${viewMonth + 1}월`;

  const prevLast = new Date(viewYear, viewMonth, 0);
  const thisLast = new Date(viewYear, viewMonth + 1, 0);

  const PLDate = prevLast.getDate();
  const PLDay = prevLast.getDay();

  const TLDate = thisLast.getDate();
  const TLDay = thisLast.getDay();

  const prevDates = [];
  const thisDates = [...Array(TLDate + 1).keys()].slice(1);
  const nextDates = [];

  if (PLDay !== 6) {
    for (let i = 0; i < PLDay + 1; i++) {
      prevDates.unshift(PLDate - i);
    }
  }

  for (let i = 1; i < 7 - TLDay; i++) {
    nextDates.push(i);
  }

  const dates = prevDates.concat(thisDates, nextDates);
  const firstDateIndex = dates.indexOf(1);
  const lastDateIndex = dates.lastIndexOf(TLDate);

  const datesElement = document.querySelector('.dates');
  datesElement.innerHTML = ''; // Clear previous dates

  dates.forEach((date, i) => {
    const condition = i >= firstDateIndex && i < lastDateIndex + 1 ? 'this' : 'other';
    const dateElement = document.createElement('div');
    dateElement.classList.add('date');
    const spanElement = document.createElement('span');
    spanElement.classList.add(condition);
    spanElement.textContent = date; // 날짜 텍스트 추가
    dateElement.appendChild(spanElement);
    
    // 텍스트 추가
    const helloText = document.createElement('div');
    helloText.classList.add('hello-text');
    helloText.textContent = "안녕";
    dateElement.appendChild(helloText);
    
    datesElement.appendChild(dateElement);
  });

  const today = new Date();
  if (viewMonth === today.getMonth() && viewYear === today.getFullYear()) {
    for (let date of document.querySelectorAll('.this')) {
      if (+date.innerText === today.getDate()) {
        date.classList.add('today');
        break;
      }
    }
  }
};

renderCalendar();

const prevMonth = () => {
  date.setDate(1);
  date.setMonth(date.getMonth() - 1);
  renderCalendar();
};

const nextMonth = () => {
  date.setDate(1);
  date.setMonth(date.getMonth() + 1);
  renderCalendar();
};

const goToday = () => {
  date = new Date();
  renderCalendar();
};
